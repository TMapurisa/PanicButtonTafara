package com.example.panicbutton;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class ContactsFragment extends Fragment {



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Contacts[] mylist = new Contacts[]{
                new Contacts("Tafara","077236452"),
                new Contacts("Radical","0321456")

        };
        View rootView = inflater.inflate(R.layout.fragment_contacts, container, false);
        RecyclerView recyclerView = (RecyclerView) rootView.findViewById(R.id.contactDisplay);
        TextView txtNocontacts = rootView.findViewById(R.id.txtNocontacts);
        if (mylist.length == 0){
            recyclerView.setVisibility(View.INVISIBLE);
            txtNocontacts.setVisibility(View.VISIBLE);
        }

        contactAdapter adapter = new contactAdapter(getContext(),mylist);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);

        // Inflate the layout for this fragment
        return rootView;
    }
}