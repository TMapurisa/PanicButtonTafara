package com.example.panicbutton;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;


public class DashboardFragment extends Fragment {
    private Button btnwlkthme;
    private Button btnShake;
    private Button btnPress;
    private Button notAssigned;
    private TextView txtAct1;
    private TextView txtAct2;
    private TextView txtAct3;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_dashboard, container, false);
        btnwlkthme = rootView.findViewById(R.id.btnWalkwithme);
        btnPress = rootView.findViewById(R.id.btnPress);
        btnShake = rootView.findViewById(R.id.btnShake);
        txtAct3 = rootView.findViewById(R.id.txtActive3);
        txtAct2 = rootView.findViewById(R.id.txtActive2);
        txtAct1 = rootView.findViewById(R.id.txtActive);
        btnwlkthme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txtAct3.setVisibility(View.VISIBLE);
            }
        });
        btnPress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txtAct2.setVisibility(View.VISIBLE);
            }
        });
        btnShake.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                btnwlkthme.setText("hi");
                txtAct1.setVisibility(View.VISIBLE);
            }
        });
        return rootView;

    }
}




//        return inflater.inflate(R.layout.fragment_dashboard, container, false);
//    }
//}