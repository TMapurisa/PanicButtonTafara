package com.example.panicbutton;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class HomeFragment extends Fragment {
    private Button panicbtn;
    private TextView panictext;
    private int btn_press = 0;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_home, container, false);
        panicbtn = rootView.findViewById(R.id.show_text_button);
        panictext = rootView.findViewById(R.id.hidden_text);


        panicbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (btn_press % 2 == 0) {
                    panicbtn.setText("Stop");
                    panictext.setVisibility(View.VISIBLE);
                    panictext.setText("SOS has been sent!");
                    sendSOSMessageWithLocation();
                    btn_press++;

                } else {
                    panictext.setVisibility(View.INVISIBLE);
                    panicbtn.setText("PANIC");
                    btn_press++;
                }

            }

            private void sendSOSMessageWithLocation() {
                ArrayList <Integer> nums = new ArrayList<>();


                // Get the user's current location
                LocationManager locationManager = (LocationManager) getContext().getSystemService(Context.LOCATION_SERVICE);

                if (ActivityCompat.checkSelfPermission(getContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

                // Construct the SOS message with the user's location
                String message = "SOS! I need help! My current location is: ";
                message += location.getLatitude() + ", " + location.getLongitude();

                // Send the SOS message
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage("+260765652261", null, message, null, null);
            }

        });

        return rootView;
    }




}